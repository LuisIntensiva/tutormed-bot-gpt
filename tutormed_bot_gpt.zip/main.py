import os
import openai
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters

# Pegando tokens das variáveis de ambiente
BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Configura a chave da API da OpenAI
openai.api_key = OPENAI_API_KEY

# Função para gerar resposta com GPT
def obter_resposta_gpt(pergunta):
    try:
        resposta = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": pergunta}],
            max_tokens=200,
            temperature=0.7
        )
        return resposta['choices'][0]['message']['content'].strip()
    except Exception as e:
        return f"Erro ao tentar responder com GPT: {e}"

# Função principal do bot
async def responder_marcacao(update: Update, context: ContextTypes.DEFAULT_TYPE):
    bot_username = (await context.bot.get_me()).username
    if f"@{bot_username}" in update.message.text:
        pergunta = update.message.text.replace(f"@{bot_username}", "").strip()
        resposta = obter_resposta_gpt(pergunta)
        await update.message.reply_text(resposta)

# Inicia o bot
if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), responder_marcacao))
    app.run_polling()
