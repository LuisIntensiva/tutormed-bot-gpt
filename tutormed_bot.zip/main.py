import os
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN")

async def responder_marcacao(update: Update, context: ContextTypes.DEFAULT_TYPE):
    bot_username = (await context.bot.get_me()).username
    if f"@{bot_username}" in update.message.text:
        await update.message.reply_text("👨‍⚕️ TutorMed aqui! Como posso ajudar você com Medicina Intensiva?")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), responder_marcacao))
    app.run_polling()
